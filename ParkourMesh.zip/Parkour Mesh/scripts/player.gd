class_name Player
extends CharacterBody2D
## Parkour player: run, jump, double jump, coyote time, jump buffering,
## wall slide, wall jump, dash, squash & stretch and particle FX.

signal died

const SPEED := 340.0
const ACCEL := 2800.0
const AIR_ACCEL := 2100.0
const FRICTION := 3400.0
const AIR_FRICTION := 1000.0
const GRAVITY_UP := 1500.0
const GRAVITY_DOWN := 2200.0
const MAX_FALL := 1150.0
const JUMP_VELOCITY := -600.0
const JUMP_CUT := 0.45
const COYOTE_TIME := 0.11
const JUMP_BUFFER_TIME := 0.13
const WALL_SLIDE_SPEED := 140.0
const WALL_JUMP_X := 440.0
const WALL_JUMP_Y := -560.0
const DASH_SPEED := 800.0
const DASH_TIME := 0.16
const DASH_COOLDOWN := 0.4

var active := true            # false during level-complete / death sequences
var control_enabled := true   # false while dead

var _coyote := 0.0
var _jump_buffer := 0.0
var _jumps_used := 0
var _max_jumps := 2
var _can_dash := true
var _dash_timer := 0.0
var _dash_cooldown := 0.0
var _dash_dir := Vector2.RIGHT
var _facing := 1.0
var _was_on_floor := false
var _fall_peak := 0.0
var _cut_jump := false
var _is_dead := false

var vis: Node2D
var squash_node: Node2D
var body_poly: Polygon2D
var eye_l: Polygon2D
var eye_r: Polygon2D
var pupil_l: Polygon2D
var pupil_r: Polygon2D
var antenna: Node2D
var cam: Camera2D
var dust: CPUParticles2D
var trail: CPUParticles2D
var burst: CPUParticles2D

var _trauma := 0.0
var _squash_tween: Tween

func _ready() -> void:
	collision_layer = 2
	collision_mask = 1
	safe_margin = 0.5
	_build_collision()
	_build_visuals()
	_build_particles()
	_build_camera()


# --- Construction ---------------------------------------------------------
func _build_collision() -> void:
	var cs := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(34, 54)
	cs.shape = shape
	add_child(cs)


func _build_visuals() -> void:
	vis = Node2D.new()
	vis.name = "Vis"
	add_child(vis)

	squash_node = Node2D.new()
	squash_node.name = "Squash"
	vis.add_child(squash_node)

	# Rounded-ish octagon body with a subtle vertical gradient.
	body_poly = Polygon2D.new()
	var w := 17.0
	var h := 27.0
	var r := 6.0
	body_poly.polygon = PackedVector2Array([
		Vector2(-w + r, -h), Vector2(w - r, -h),
		Vector2(w, -h + r), Vector2(w, h - r),
		Vector2(w - r, h), Vector2(-w + r, h),
		Vector2(-w, h - r), Vector2(-w, -h + r),
	])
	body_poly.vertex_colors = PackedColorArray([
		Color("#7dd3fc"), Color("#38bdf8"), Color("#22d3ee"),
		Color("#0891b2"), Color("#155e75"), Color("#155e75"),
		Color("#0891b2"), Color("#22d3ee"),
	])
	squash_node.add_child(body_poly)

	antenna = Node2D.new()
	antenna.position = Vector2(0, -27)
	squash_node.add_child(antenna)
	var stem := Line2D.new()
	stem.points = PackedVector2Array([Vector2.ZERO, Vector2(0, -10)])
	stem.width = 3.0
	stem.default_color = Color("#a5f3fc")
	antenna.add_child(stem)
	var bulb := Polygon2D.new()
	bulb.polygon = _diamond_points(Vector2(0, -14), 5.0)
	bulb.color = Color("#f472b6")
	antenna.add_child(bulb)

	eye_l = _make_eye(Vector2(-6.5, -8))
	eye_r = _make_eye(Vector2(6.5, -8))
	squash_node.add_child(eye_l)
	squash_node.add_child(eye_r)
	pupil_l = eye_l.get_child(0)
	pupil_r = eye_r.get_child(0)


static func _diamond_points(center: Vector2, r: float) -> PackedVector2Array:
	return PackedVector2Array([
		center + Vector2(0, -r), center + Vector2(r * 0.62, 0),
		center + Vector2(0, r), center + Vector2(-r * 0.62, 0),
	])


func _make_eye(pos: Vector2) -> Polygon2D:
	var eye := Polygon2D.new()
	eye.position = pos
	eye.color = Color(0.05, 0.09, 0.16)
	eye.polygon = PackedVector2Array([
		Vector2(-4.5, -4.5), Vector2(4.5, -4.5),
		Vector2(4.5, 3.5), Vector2(0, 6.5), Vector2(-4.5, 3.5),
	])
	var pupil := Polygon2D.new()
	pupil.color = Color("#e0fbff")
	pupil.polygon = PackedVector2Array([
		Vector2(-2, -2), Vector2(2, -2), Vector2(2, 2), Vector2(-2, 2),
	])
	eye.add_child(pupil)
	return eye


func _build_particles() -> void:
	dust = CPUParticles2D.new()
	dust.amount = 12
	dust.lifetime = 0.45
	dust.local_coords = false
	dust.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	dust.emission_rect_extents = Vector2(9, 3)
	dust.direction = Vector2.UP
	dust.spread = 55.0
	dust.gravity = Vector2(0, -30)
	dust.initial_velocity_min = 15.0
	dust.initial_velocity_max = 40.0
	dust.scale_amount_min = 1.5
	dust.scale_amount_max = 4.0
	dust.color = Color(0.65, 0.8, 0.95, 0.35)
	dust.position = Vector2(0, 26)
	dust.emitting = false
	add_child(dust)

	trail = CPUParticles2D.new()
	trail.amount = 26
	trail.lifetime = 0.28
	trail.local_coords = false
	trail.spread = 180.0
	trail.gravity = Vector2.ZERO
	trail.initial_velocity_min = 0.0
	trail.initial_velocity_max = 30.0
	trail.scale_amount_min = 2.0
	trail.scale_amount_max = 5.0
	var g := Gradient.new()
	g.colors = PackedColorArray([Color(0.35, 0.95, 1.0, 0.85), Color(0.35, 0.95, 1.0, 0.0)])
	trail.color_ramp = g
	trail.emitting = false
	add_child(trail)

	burst = CPUParticles2D.new()
	burst.one_shot = true
	burst.explosiveness = 1.0
	burst.amount = 14
	burst.lifetime = 0.35
	burst.local_coords = false
	burst.direction = Vector2.UP
	burst.spread = 80.0
	burst.gravity = Vector2(0, 900)
	burst.initial_velocity_min = 120.0
	burst.initial_velocity_max = 230.0
	burst.scale_amount_min = 2.0
	burst.scale_amount_max = 4.0
	burst.color = Color(0.65, 0.85, 1.0, 0.7)
	burst.position = Vector2(0, 24)
	burst.emitting = false
	add_child(burst)


func _build_camera() -> void:
	cam = Camera2D.new()
	cam.name = "Cam"
	cam.position_smoothing_enabled = true
	cam.position_smoothing_speed = 7.0
	cam.zoom = Vector2(1.0, 1.0)
	add_child(cam)
	cam.make_current()
	add_to_group("camera")


func setup_camera(bounds: Rect2) -> void:
	cam.limit_left = int(bounds.position.x)
	cam.limit_top = int(bounds.position.y)
	cam.limit_right = int(bounds.end.x)
	cam.limit_bottom = int(bounds.end.y)
	cam.reset_smoothing()


func shake(amount: float) -> void:
	_trauma = clampf(_trauma + amount, 0.0, 1.0)


# --- Main loop ------------------------------------------------------------
func _physics_process(delta: float) -> void:
	if _is_dead:
		return

	var axis := 0.0
	if active and control_enabled:
		axis = Input.get_axis("move_left", "move_right")

	if axis != 0.0:
		_facing = signf(axis)

	_dash_cooldown = maxf(0.0, _dash_cooldown - delta)

	if active and control_enabled and Input.is_action_just_pressed("dash") \
			and _can_dash and _dash_cooldown <= 0.0 and _dash_timer <= 0.0:
		_start_dash(axis)

	if _dash_timer > 0.0:
		_dash_timer -= delta
		velocity = _dash_dir * DASH_SPEED
		move_and_slide()
		if is_on_floor() or is_on_ceiling() or is_on_wall():
			_end_dash()
	else:
		_apply_gravity(delta)
		_horizontal_move(delta, axis)
		_wall_interactions(delta, axis)
		_jumping(delta, axis)
		move_and_slide()

	_post_move(delta)


func _apply_gravity(delta: float) -> void:
	if not is_on_floor():
		var g := GRAVITY_UP if velocity.y < 0.0 else GRAVITY_DOWN
		velocity.y = minf(velocity.y + g * delta, MAX_FALL)


func _horizontal_move(delta: float, axis: float) -> void:
	var on_floor := is_on_floor()
	if absf(axis) > 0.01:
		var a := ACCEL if on_floor else AIR_ACCEL
		velocity.x = move_toward(velocity.x, axis * SPEED, a * delta)
	else:
		var f := FRICTION if on_floor else AIR_FRICTION
		velocity.x = move_toward(velocity.x, 0.0, f * delta)


func _wall_interactions(_delta: float, axis: float) -> void:
	if not is_on_floor() and is_on_wall_only():
		var normal := get_wall_normal()
		var pressing_into_wall := (normal.x > 0.0 and Input.is_action_pressed("move_left")) \
			or (normal.x < 0.0 and Input.is_action_pressed("move_right"))
		if pressing_into_wall or (absf(axis) > 0.01 and signf(axis) == -signf(normal.x)):
			if velocity.y > 0.0:
				velocity.y = minf(velocity.y, WALL_SLIDE_SPEED)
			_jumps_used = mini(_jumps_used, 1)
			_can_dash = true


func _jumping(delta: float, _axis: float) -> void:
	_coyote = COYOTE_TIME if is_on_floor() else maxf(0.0, _coyote - delta)
	if active and control_enabled and Input.is_action_just_pressed("jump"):
		_jump_buffer = JUMP_BUFFER_TIME
	else:
		_jump_buffer = maxf(0.0, _jump_buffer - delta)

	if _jump_buffer > 0.0:
		if is_on_wall_only():
			_do_wall_jump()
		elif _coyote > 0.0:
			_do_ground_jump()
		elif _jumps_used < _max_jumps:
			_do_air_jump()

	# Variable jump height.
	if active and control_enabled and Input.is_action_just_released("jump") \
			and velocity.y < 0.0 and not _cut_jump:
		velocity.y *= JUMP_CUT
		_cut_jump = true


func _do_ground_jump() -> void:
	velocity.y = JUMP_VELOCITY
	_coyote = 0.0
	_jump_buffer = 0.0
	_cut_jump = false
	_sfx("jump")
	_burst_fx()
	_squash(Vector2(0.72, 1.28))


func _do_air_jump() -> void:
	velocity.y = JUMP_VELOCITY * 0.92
	velocity.x = move_toward(velocity.x, _facing * SPEED, 200.0)
	_jumps_used += 1
	_jump_buffer = 0.0
	_cut_jump = false
	_sfx("double_jump", -4.0)
	_burst_fx()
	_spin_fx()
	_squash(Vector2(0.78, 1.22))


func _do_wall_jump() -> void:
	var normal := get_wall_normal()
	velocity.x = normal.x * WALL_JUMP_X
	velocity.y = WALL_JUMP_Y
	_facing = signf(normal.x)
	_jumps_used = mini(_jumps_used, 1)
	_can_dash = true
	_jump_buffer = 0.0
	_cut_jump = false
	_sfx("wall_jump", -3.0)
	_burst_fx()
	_squash(Vector2(0.75, 1.25))


func _start_dash(axis: float) -> void:
	var dir_x := axis
	if absf(dir_x) < 0.01:
		dir_x = _facing
	_dash_dir = Vector2(signf(dir_x), 0.0)
	_dash_timer = DASH_TIME
	_dash_cooldown = DASH_COOLDOWN
	_can_dash = false
	_cut_jump = true
	velocity = _dash_dir * DASH_SPEED
	trail.emitting = true
	_sfx("dash")
	shake(0.18)
	_squash(Vector2(1.25, 0.78))


func _end_dash() -> void:
	_dash_timer = 0.0
	trail.emitting = false


func _post_move(delta: float) -> void:
	# Landing detection.
	if is_on_floor() and not _was_on_floor:
		_jumps_used = 0
		_can_dash = true
		_cut_jump = false
		if not _is_dead and _fall_peak > 260.0:
			_sfx("land", -9.0)
			_squash(Vector2(1.28, 0.74))
		_fall_peak = 0.0
	elif not is_on_floor():
		_fall_peak = maxf(_fall_peak, velocity.y)
	_was_on_floor = is_on_floor()

	# Visual updates.
	vis.scale.x = _facing if not _is_dead else vis.scale.x
	var tilt := clampf(velocity.x * 0.00025, -0.09, 0.09)
	if is_on_floor():
		tilt *= 0.4
	squash_node.rotation = lerp_angle(squash_node.rotation, tilt, 10.0 * delta)
	var look_x := clampf(velocity.x / SPEED, -1.0, 1.0) * 1.8
	var look_y := clampf(velocity.y / 900.0, -1.0, 1.0) * 1.6
	pupil_l.position = Vector2(look_x, look_y)
	pupil_r.position = Vector2(look_x, look_y)
	antenna.rotation = clampf(-velocity.x * 0.0009, -0.45, 0.45)

	dust.emitting = is_on_floor() and absf(velocity.x) > 60.0 and active and not _is_dead

	# Camera shake decay.
	if _trauma > 0.0:
		_trauma = maxf(0.0, _trauma - delta * 1.8)
		var s := _trauma * _trauma
		cam.offset = Vector2(
			randf_range(-1.0, 1.0) * 14.0 * s,
			randf_range(-1.0, 1.0) * 10.0 * s)
	else:
		cam.offset = Vector2.ZERO


# --- Helpers --------------------------------------------------------------
func dash_ratio() -> float:
	if _dash_timer > 0.0:
		return 1.0
	return clampf(1.0 - _dash_cooldown / DASH_COOLDOWN, 0.0, 1.0)


func refresh_air_moves() -> void:
	## Called by springs etc.
	_jumps_used = 0
	_can_dash = true
	_cut_jump = false


func bounce(strength: float) -> void:
	velocity.y = -strength
	_cut_jump = false
	refresh_air_moves()
	_squash(Vector2(0.7, 1.32))


func die() -> void:
	if _is_dead or not active:
		return
	_is_dead = true
	control_enabled = false
	_end_dash()
	dust.emitting = false
	trail.emitting = false
	velocity = Vector2.ZERO
	_sfx("death")
	shake(0.55)
	_spawn_death_particles()
	vis.visible = false
	set_deferred("collision_layer", 0)
	died.emit()


func respawn(at: Vector2) -> void:
	global_position = at
	velocity = Vector2.ZERO
	_is_dead = false
	control_enabled = true
	active = true
	_jumps_used = 0
	_can_dash = true
	_coyote = 0.0
	_jump_buffer = 0.0
	_cut_jump = false
	_dash_timer = 0.0
	_was_on_floor = false
	vis.visible = true
	vis.scale.x = 1.0
	squash_node.rotation = 0.0
	set_deferred("collision_layer", 2)
	if cam != null:
		cam.reset_smoothing()


func _spawn_death_particles() -> void:
	var p := CPUParticles2D.new()
	p.one_shot = true
	p.explosiveness = 1.0
	p.amount = 34
	p.lifetime = 0.6
	p.local_coords = false
	p.spread = 180.0
	p.gravity = Vector2(0, 1300)
	p.initial_velocity_min = 150.0
	p.initial_velocity_max = 420.0
	p.scale_amount_min = 2.0
	p.scale_amount_max = 5.0
	var g := Gradient.new()
	g.colors = PackedColorArray([Color("#f472b6"), Color(0.95, 0.45, 0.71, 0.0)])
	p.color_ramp = g
	get_parent().add_child(p)
	p.global_position = global_position
	p.emitting = true
	get_tree().create_timer(1.0).timeout.connect(p.queue_free)


func _squash(s: Vector2) -> void:
	if _squash_tween != null and _squash_tween.is_valid():
		_squash_tween.kill()
	squash_node.scale = s
	_squash_tween = create_tween()
	_squash_tween.tween_property(squash_node, "scale", Vector2.ONE, 0.18) \
		.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _burst_fx() -> void:
	burst.restart()
	burst.emitting = true


func _spin_fx() -> void:
	var tw := create_tween()
	tw.tween_property(squash_node, "rotation", squash_node.rotation + TAU, 0.3) \
		.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)


func _sfx(n: String, vol_db: float = 0.0) -> void:
	Globals.play_sfx(n, vol_db)
