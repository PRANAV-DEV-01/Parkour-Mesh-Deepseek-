class_name MovingPlatform
extends AnimatableBody2D
## Platform that glides between its start position and start + move_offset.

@export var size := Vector2(180.0, 28.0)
@export var move_offset := Vector2(320.0, 0.0)
@export var duration := 2.4
@export var start_delay := 0.0

var _lines: Array[Line2D]

func _ready() -> void:
	sync_to_physics = true
	collision_layer = 1
	collision_mask = 0
	add_to_group("accent")
	_lines = Platform.add_platform_visuals(self, size)
	var tw := create_tween()
	tw.set_process_mode(Tween.TWEEN_PROCESS_PHYSICS)
	tw.set_trans(Tween.TRANS_SINE)
	tw.set_ease(Tween.EASE_IN_OUT)
	tw.set_loops()
	if start_delay > 0.0:
		tw.tween_interval(start_delay)
	tw.tween_property(self, "position", position + move_offset, duration)
	tw.tween_interval(start_delay * 0.5)
	tw.tween_property(self, "position", position, duration)


func set_accent(c: Color) -> void:
	if _lines.size() >= 2:
		_lines[0].default_color = c
		_lines[1].default_color = Color(c.r, c.g, c.b, 0.22)
