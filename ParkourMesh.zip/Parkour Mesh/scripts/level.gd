class_name GameLevel
extends Node2D
## Per-level controller: tracks stats, deaths/respawns, checkpoints,
## coin collection, goal completion and restart flow.

@export var display_name := "LEVEL 1"
@export var accent_color := Color("#22d3ee")
@export var camera_bounds := Rect2(-240, -900, 3800, 1700)
@export var kill_y := 1100.0

var player: Player
var hud: GameHUD

var spawn_point := Vector2.ZERO
var checkpoint_pos := Vector2.ZERO
var current_checkpoint: Checkpoint = null

var level_coins := 0
var level_deaths := 0
var coin_total := 0
var completed := false

var _respawning := false

func _ready() -> void:
	add_to_group("level")
	Globals.load_progress()

	var bg := BackgroundGrid.new()
	add_child(bg)

	player = get_node("Player") as Player
	hud = get_node("HUD") as GameHUD

	spawn_point = player.global_position
	checkpoint_pos = spawn_point

	player.died.connect(_on_player_died)

	coin_total = get_tree().get_nodes_in_group("shard").size()
	for n in get_tree().get_nodes_in_group("accent"):
		n.set_accent(accent_color)

	player.setup_camera(camera_bounds)
	hud.setup(player, display_name, coin_total, accent_color)
	hud.restart_requested.connect(_do_restart)
	hud.next_level_requested.connect(_on_next_level)
	hud.menu_requested.connect(_go_menu)


func _physics_process(_delta: float) -> void:
	if not completed and player.global_position.y > kill_y:
		player.die()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("restart") and not completed and not get_tree().paused:
		_do_restart()
		get_viewport().set_input_as_handled()


# ------------------------------------------------------------------ events
func on_coin_collected() -> void:
	level_coins += 1
	hud.set_coins(level_coins)


func register_checkpoint(cp: Checkpoint) -> void:
	if current_checkpoint != null and current_checkpoint != cp:
		current_checkpoint.deactivate()
	current_checkpoint = cp
	checkpoint_pos = cp.spawn_position()


func on_goal_reached() -> void:
	if completed:
		return
	completed = true
	hud.timing = false
	var is_last := Globals.current_level_index >= Globals.LEVELS.size() - 1
	Globals.finish_level(hud.get_elapsed(), level_coins, level_deaths)
	await get_tree().create_timer(0.75).timeout
	Globals.play_sfx("win")
	hud.show_complete(level_coins, level_deaths, is_last)


# ------------------------------------------------------------------ flow
func _on_player_died() -> void:
	if completed or _respawning:
		return
	_respawning = true
	level_deaths += 1
	hud.set_deaths(level_deaths)
	await get_tree().create_timer(0.55).timeout
	if not is_inside_tree():
		return
	await hud.fade_out(0.16)
	player.respawn(checkpoint_pos)
	hud.fade_in(0.32)
	await get_tree().create_timer(0.2).timeout
	_respawning = false


func _do_restart() -> void:
	completed = true
	get_tree().paused = false
	await hud.fade_out(0.22)
	Globals.restart_level()


func _on_next_level() -> void:
	completed = true
	Globals.next_level()


func _go_menu() -> void:
	get_tree().paused = false
	await hud.fade_out(0.22)
	Globals.to_main_menu()
